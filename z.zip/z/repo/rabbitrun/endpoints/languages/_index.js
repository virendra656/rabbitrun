"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const LanguageGet = require("./languages.get");
exports.LanguageGet = LanguageGet;
const LanguagePost = require("./languages.post");
exports.LanguagePost = LanguagePost;

//# sourceMappingURL=_index.js.map
