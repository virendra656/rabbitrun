"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CustomerPost = require("./customer.post");
exports.CustomerPost = CustomerPost;

//# sourceMappingURL=_index.js.map
