"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const LanguageController = require("./languages/_index");
exports.LanguageController = LanguageController;
const AppUserController = require("./appusers/_index");
exports.AppUserController = AppUserController;
const CustomerController = require("./customers/_index");
exports.CustomerController = CustomerController;
const DriverController = require("./drivers/_index");
exports.DriverController = DriverController;

//# sourceMappingURL=_index.js.map
