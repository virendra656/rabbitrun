"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function addTwo(input) {
    input += 2;
    return input;
}
exports.addTwo = addTwo;

//# sourceMappingURL=test.js.map
