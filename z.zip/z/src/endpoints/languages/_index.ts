import * as LanguageGet from './languages.get'
import * as LanguagePost from './languages.post'

export { LanguageGet, LanguagePost }
