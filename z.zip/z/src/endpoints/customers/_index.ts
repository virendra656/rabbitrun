import * as CustomerPost from "./customer.post";

export {CustomerPost}
