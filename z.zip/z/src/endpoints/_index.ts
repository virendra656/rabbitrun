import * as LanguageController from './languages/_index'
import * as AppUserController from './appusers/_index'
import * as CustomerController from './customers/_index'
import * as DriverController from './drivers/_index'

export { LanguageController, AppUserController, CustomerController, DriverController }
