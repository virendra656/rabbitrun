import { Express } from 'express'
import { DriverController } from '../endpoints/_index'
import { CONSTANTS } from '../util/SiteConfig';
import { AuthGuard } from '../util/helper';




export function routes(app: Express) {
  app.post(CONSTANTS.apiBasePath + 'driver/register', DriverController.DriverPost.register);
  app.post(CONSTANTS.apiBasePath + 'driver/login', DriverController.DriverPost.login);
  app.post(CONSTANTS.apiBasePath + 'driver/updateDriverLocation', [AuthGuard], DriverController.DriverPost.updateDriverLocation);
  app.post(CONSTANTS.apiBasePath + 'driver/nearByDrivers', [AuthGuard], DriverController.DriverPost.nearByDrivers);
}
